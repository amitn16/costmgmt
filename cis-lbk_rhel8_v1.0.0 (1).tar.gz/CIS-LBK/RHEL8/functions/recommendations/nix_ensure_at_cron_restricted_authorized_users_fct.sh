#!/usr/bin/env sh
#
# CIS-LBK Cloud Team Built Recommendation Function
# ~/CIS-LBK/functions/fct/nix_ensure_at_cron_restricted_authorized_users_fct.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       09/21/20    Recommendation "Ensure at/cron is restricted to authorized users"
#
ensure_at_cron_restricted_authorized_users_fct()
{

	echo
	echo "**** $RN $RNA"
	[ -e /etc/cron.deny ] && rm -f /etc/cron.deny
	[ -e /etc/at.deny ] && rm -f /etc/at.deny
	[ ! -f /etc/cron.deny ] && touch /etc/cron.deny
	[ ! -f /etc/at.deny ] && touch /etc/at.deny
	chmod og-rwx /etc/cron.allow /etc/at.allow
	chown root:root /etc/cron.allow /etc/at.allow

	return "${XCCDF_RESULT_PASS:-201}"

}