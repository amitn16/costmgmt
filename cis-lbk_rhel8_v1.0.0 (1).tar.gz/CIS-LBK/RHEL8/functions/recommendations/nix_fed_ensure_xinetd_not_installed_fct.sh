#!/usr/bin/env sh
#
# CIS-LBK Cloud Team Built Recommendation Function
# ~/CIS-LBK/functions/fct/nix_fed_ensure_xinetd_not_installed_fct.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       09/21/20    Recommendation "Ensure xinetd is not installed"
#
fed_ensure_xinetd_not_installed_fct()
{

	echo
	echo "**** Ensure xinetd is not installed"
	if [ -z "$PQ" ] || [ -z "$PR" ]; then
		nix_package_manager_set
	fi
	$PQ 2>>/dev/null xinetd && $PR -y xinetd

	return "${XCCDF_RESULT_PASS:-201}"
}